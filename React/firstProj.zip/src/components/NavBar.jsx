import React from 'react'
import './NavBar.css'

const NavBar = ()=>{
    return (
        <>
        <div className="nv">
        <h5>home</h5>
        <h5>about</h5>
        <h5>order</h5>
        <h5>review</h5>
        </div>
        </>

    )
}
export default NavBar